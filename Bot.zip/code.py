"""
 
All coordinates assume a screen resolution of 1600x900, and Chrome 
maximized with the Bookmarks Toolbar enabled.
Down key has been hit 0 times to center play area in browser.
x_pad = 304
y_pad = 342
Play area =  x_pad+1, y_pad+1, 796, 825
"""
"""
 
Plate cords:
 85 206
 172 202
 277 204
 381 204
 480 203
 578 203
    
"""

'''
Recipes:
 
    onigiri
        2 rice, 1 nori
     
    caliroll:
        1 rice, 1 nori, 1 roe
         
    gunkan:
        1 rice, 1 nori, 2 roe
'''
# Globals
# ------------------
 
x_pad = 304
y_pad = 342


import pyscreenshot as ImageGrab
import os
import time
import win32con
import win32api
from PIL import Image, ImageOps
from numpy import *
import turtle
import webbrowser

class Cord:
    Mat = (191, 323)
    f_shrimp = (34 ,325)
    f_rice = (90 ,333)
    f_nori = (37 ,387)
    f_roe = (88 ,381)
    f_salmon = (31, 434)
    f_unagi = (99, 436)
        #-----------------------------------    
         
    phone = (581, 350)
 
    menu_toppings = (521, 267)
     
    t_shrimp = (474, 219)
    t_nori = (474, 281)
    t_roe = (596, 271)
    t_salmon = (494, 328)
    t_unagi = (591, 228)
    t_exit = (593, 326)
 
    menu_rice = (527, 288)
    buy_rice = (517, 277)

    menu_sake = (532, 310)
    buy_sake=(518, 265)
     
    delivery_norm = (496, 287)

    level_up = (320, 370)
    two_con = (300, 363)
    try_again = (244, 377)

class Blank:
    seat_1 = 7621
    seat_2 = 5893
    seat_3 = 11342
    seat_4 = 10187
    seat_5 = 5738
    seat_6 = 8201

def screenGrab():
    box = (x_pad + 1,y_pad+1,x_pad+640,y_pad+480)
    im = ImageGrab.grab(box)
    #also can use bbox in im=... instead of calling box in
    #im.show()
    #im.save(os.getcwd() + '\\full_snap__' + str(int(time.time())) + '.png', 'PNG')
    return im

def grab():
    box = (x_pad + 1,y_pad+1,x_pad+640,y_pad+480)
    im = ImageOps.grayscale(ImageGrab.grab(box))
    a = array(im.getcolors())
    a = a.sum()
    return a
##def levelup(s):
##    if  s == screenGrab():
##        s.getpixel(Cord.level_up) != ((225, 181, 105))
##        print('level up')
##        mousePos(Cord.level_up)
##        leftClick()
##        time.sleep(.05)
##        mosusePos(Cord.two_con)
##        leftClick()

def main():
    startGame()
    while True:
        check_bubs()
        
def leftClick():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,0,0)
    time.sleep(.1)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,0,0)
    print ( "Click.")
    #completely optional. But nice for debugging purposes.
def leftDown():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,0,0)
    time.sleep(.1)
    print ('left Down')
         
def leftUp():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,0,0)
    time.sleep(.1)
    print ('left release')
def mousePos(cord):
    win32api.SetCursorPos((x_pad + cord[0], y_pad + cord[1]))
def get_cords():
    x,y = win32api.GetCursorPos()
    x = x - x_pad
    y = y - y_pad
    print (x,y)

def startGame():
    #location of first menu
    mousePos((320, 200))
    leftClick()
    time.sleep(.1)
     
    #location of second menu
    mousePos((325, 383))
    leftClick()
    time.sleep(.1)
     
    #location of third menu
    mousePos((586,442))
    leftClick()
    time.sleep(.1)
     
    #location of fourth menu
    mousePos((300, 363))
    leftClick()
    time.sleep(.1)

def clear_tables():
    mousePos((85, 206))
    leftClick()
    mousePos((172, 202))
    leftClick()
    mousePos((277, 204))
    leftClick()
    mousePos((381, 204))
    leftClick()
    mousePos((480, 203))
    leftClick()
    mousePos((578, 203))
    leftClick()
    time.sleep(.1)

def checkFood():
        for i , j in foodOnHand.items():
            if i == 'nori' or i == 'rice' or i == 'roe':
                if j <5:
                    print ('%s is low and needs to be replenished' % i)
                    buyFood(i)
def checkFood2():
        for i , j in foodOnHand.items():
            if i == 'salmon' or i == 'unagi' or i == 'shrimp':
                if j <= 2:
                    print ('%s is low and needs to be replenished' % i)
                    buyFood(i)

def checkFood3():
        for i , j in foodOnHand.items():
            if i == 'sake':
                if j <= 1:
                    print ('%s is low and needs to be replenished' % i)
                    buyFood(i)

foodOnHand = {'shrimp':5,
              'rice':10,
              'nori':10,
              'roe':10,
              'salmon':5,
              'sake':2,
              'unagi':5 }

sushiTypes = {2049:'onigiri', 
              2306:'caliroll',
              1976:'gunkan',
              1853:'salmonroll',
              2300:'shrimpsushi',
              2101:'unagiroll',
              2515:'dragonroll',
              3791:'combo',}



def makeFood(food):
    if food == 'caliroll':
        print ('Making a caliroll')
        foodOnHand['rice'] -= 1
        foodOnHand['nori'] -= 1
        foodOnHand['roe'] -= 1 
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_nori)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_roe)
        time.sleep(.05)
        leftClick()
        time.sleep(.1)
        foldMat()
        time.sleep(1.5)
     
    elif food == 'onigiri':
        print ('Making a onigiri')
        foodOnHand['rice'] -= 2 
        foodOnHand['nori'] -= 1 
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_nori)
        time.sleep(.05)
        leftClick()
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        time.sleep(.1)
        foldMat()
        time.sleep(.05)
         
        time.sleep(1.5)
 
    elif food == 'gunkan':
        print ('Making a gunkan')
        foodOnHand['rice'] -= 1 
        foodOnHand['nori'] -= 1 
        foodOnHand['roe'] -= 2 
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_roe)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_nori)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_roe)
        time.sleep(.05)
        leftClick()
        time.sleep(.1)
        foldMat()
        time.sleep(.05)

    elif food == 'salmonroll':
        print ('Making a salmon roll')
        foodOnHand['rice'] -= 1 
        foodOnHand['nori'] -= 1 
        foodOnHand['salmon'] -= 2 
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_salmon)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_nori)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_salmon)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        foldMat()
        time.sleep(.05) 
    elif food == 'shrimpsushi':
        print ('Making a shrimp sushi')
        foodOnHand['rice'] -= 1 
        foodOnHand['nori'] -= 1 
        foodOnHand['shrimp'] -= 2 
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_shrimp)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_nori)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_shrimp)
        time.sleep(.05)
        leftClick()
        time.sleep(.1)
        foldMat()
        time.sleep(.1)
    elif food == 'unagiroll':
        print ('Making a unagi roll')
        foodOnHand['rice'] -= 1 
        foodOnHand['nori'] -= 1 
        foodOnHand['unagi'] -= 2 
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_unagi)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_nori)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_unagi)
        time.sleep(.05)
        leftClick()
        time.sleep(.1)
        foldMat()
        time.sleep(.1)
    elif food == 'dragonroll':
        print ('Making a Dragon roll')
        foodOnHand['rice'] -= 2 
        foodOnHand['nori'] -= 1
        foodOnHand['roe'] -= 1
        foodOnHand['unagi'] -= 2 
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_nori)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_roe)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_unagi)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_unagi)
        time.sleep(.05)
        leftClick()
        time.sleep(.1)
        foldMat()
        time.sleep(.1)
    elif food == 'combo':
        print ('Making a combo')
        foodOnHand['rice'] -= 2 
        foodOnHand['nori'] -= 1
        foodOnHand['roe'] -= 1
        foodOnHand['unagi'] -= 1
        foodOnHand['shrimp'] -= 1
        foodOnHand['salmon'] -= 1 
        mousePos(Cord.f_rice)
        time.sleep(.2)
        leftClick()
        time.sleep(.2)
        mousePos(Cord.f_nori)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_rice)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_roe)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_unagi)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_shrimp)
        time.sleep(.05)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.f_salmon)
        time.sleep(.05)
        leftClick()
        time.sleep(.1)
        foldMat()
        time.sleep(.1) 
def foldMat():
        mousePos((Cord.Mat)) 
        leftClick()
        time.sleep(.1)


def buyFood(food):
     
        mousePos(Cord.phone)
     
        mousePos(Cord.menu_toppings)
         
         
        mousePos(Cord.t_shrimp)
        mousePos(Cord.t_roe)
        mousePos(Cord.t_nori)
        mousePos(Cord.t_salmon)
        mousePos(Cord.t_unagi)
        mousePos(Cord.t_exit)
         
        mousePos(Cord.menu_rice)
        mousePos(Cord.buy_rice)
         
        mousePos(Cord.delivery_norm)

     
        if      food == 'rice':
                mousePos(Cord.phone)
                time.sleep(.1)
                leftClick()
                mousePos(Cord.menu_rice)
                time.sleep(.05)
                leftClick()
                s = screenGrab()
                if      s.getpixel(Cord.buy_rice) != ((118, 83, 85)):
                        print ('rice is available')
                        mousePos(Cord.buy_rice)
                        time.sleep(.1)
                        leftClick()
                        mousePos(Cord.delivery_norm)
                        foodOnHand['rice'] += 10 
                        time.sleep(.1)
                        leftClick()
                        time.sleep(2.5)
                else:
                        print ('rice is NOT available')
                        mousePos(Cord.t_exit)
                        leftClick()
                        time.sleep(1)
                        buyFood(food)
                        
         
                     
        if      food == 'nori':
                mousePos(Cord.phone)
                time.sleep(.1)
                leftClick()
                mousePos(Cord.menu_toppings)
                time.sleep(.1)
                leftClick()
                s = screenGrab()
                time.sleep(.2)
                if      s.getpixel(Cord.t_nori) != ((109, 123, 127)):
                        print ('nori is available')
                        mousePos(Cord.t_nori)
                        time.sleep(.5)
                        leftClick()
                        mousePos(Cord.delivery_norm)
                        foodOnHand['nori'] += 10 
                        time.sleep(.2)
                        leftClick()
                        time.sleep(.2)
                        leftClick()
                        time.sleep(2.5)
                else:
                       print ('nori is NOT available')
                       mousePos(Cord.t_exit)
                       leftClick()
                       time.sleep(1)
                       buyFood(food)
        if      food == 'roe':
                mousePos(Cord.phone)
                time.sleep(.1)
                leftClick()
                mousePos(Cord.menu_toppings)
                time.sleep(.05)
                leftClick()
                s = screenGrab()
                time.sleep(.3)
                if     s.getpixel(Cord.t_roe) != ((109, 123, 127)):
                       print ('roe is available')
                       mousePos(Cord.t_roe)                      
                       time.sleep(1)
                       leftClick()
                       mousePos(Cord.delivery_norm)
                       foodOnHand['roe'] += 10 
                       time.sleep(.1)
                       leftClick()
                       time.sleep(2.5)
                else:
                       print ('roe is NOT available')
                       mousePos(Cord.t_exit)
                       leftClick()
                       time.sleep(1)
                       buyFood(food)
        if      food == 'salmon':
                mousePos(Cord.phone)
                time.sleep(.1)
                leftClick()
                mousePos(Cord.menu_toppings)
                time.sleep(.05)
                leftClick()
                s = screenGrab()
                time.sleep(.1)
                if     s.getpixel(Cord.t_salmon) != ((127, 71, 47)):
                       print ('salmon is available')
                       mousePos(Cord.t_salmon)
                       time.sleep(.1)
                       leftClick()
                       mousePos(Cord.delivery_norm)
                       foodOnHand['salmon'] += 5 
                       time.sleep(.1)
                       leftClick()
                       time.sleep(2.5)
                else:
                       print ('salmon is NOT available')
                       mousePos(Cord.t_exit)
                       leftClick()
                       time.sleep(1)
                       buyFood(food)

        if      food == 'shrimp':
                mousePos(Cord.phone)
                time.sleep(.1)
                leftClick()
                mousePos(Cord.menu_toppings)
                time.sleep(.05)
                leftClick()
                s = screenGrab()
                 
                time.sleep(.1)
                if      s.getpixel(Cord.t_shrimp) != ((127, 52, 6)):
                        print ('shrimp is available')
                        mousePos(Cord.t_shrimp)
                        time.sleep(.1)
                        leftClick()
                        mousePos(Cord.delivery_norm)
                        foodOnHand['shrimp'] += 5 
                        time.sleep(.1)
                        leftClick()
                        time.sleep(2.5)
                else:
                        print ('shrimp is NOT available')
                        mousePos(Cord.t_exit)
                        leftClick()
                        time.sleep(1)
                        buyFood(food)      


        if      food == 'unagi':
                mousePos(Cord.phone)
                time.sleep(.1)
                leftClick()
                mousePos(Cord.menu_toppings)
                time.sleep(.05)
                leftClick()
                s = screenGrab()
                 
                time.sleep(.1)
                if      s.getpixel(Cord.t_unagi) != ((60, 29, 2)):
                        print ('unagi is available')
                        mousePos(Cord.t_unagi)
                        time.sleep(.1)
                        leftClick()
                        mousePos(Cord.delivery_norm)
                        foodOnHand['unagi'] += 5
                        time.sleep(.1)
                        leftClick()
                        time.sleep(2.5)
                else:
                        print ('unagi is NOT available')
                        mousePos(Cord.t_exit)
                        leftClick()
                        time.sleep(1)
                        buyFood(food)
        if      food == 'sake':
                mousePos(Cord.phone)
                time.sleep(.1)
                leftClick()
                mousePos(Cord.menu_sake)
                time.sleep(.05)
                leftClick()
                s = screenGrab()
                 
                time.sleep(.1)
                if      s.getpixel(Cord.buy_sake) != ((127, 102, 76)):
                        print ('sake is available')
                        mousePos(Cord.buy_sake)
                        time.sleep(.1)
                        leftClick()
                        mousePos(Cord.delivery_norm)
                        foodOnHand['sake'] += 2
                        time.sleep(.1)
                        leftClick()
                        time.sleep(2.5)
                else:
                        print ('sake is NOT available')
                        mousePos(Cord.t_exit)
                        leftClick()
                        time.sleep(1)
                        buyFood(food)


def get_seat_one():
    box = (331,404,331+61,404+15)
    grayscale = grab()
    im = ImageOps.grayscale(ImageGrab.grab(box))
    a = array(im.getcolors())
    a = a.sum()
    print (a)
    return a
 
def get_seat_two():
    box = (432,404,432+61,404+15)
    im = ImageOps.grayscale(ImageGrab.grab(box))
    a = array(im.getcolors())
    a = a.sum()
    print (a)
    return a
 
def get_seat_three():
    bbox = (533,404,533+61,404+15)
    im = ImageOps.grayscale(ImageGrab.grab(bbox))
    a = array(im.getcolors())
    a = a.sum()
    print (a)
    return a
 
def get_seat_four():
    box = (634,404,634+61,404+15)
    im = ImageOps.grayscale(ImageGrab.grab(box))
    a = array(im.getcolors())
    a = a.sum()
    print (a)
    return a
 
def get_seat_five():
    box = (735,404,735+61,404+15)
    im = ImageOps.grayscale(ImageGrab.grab(box))
    a = array(im.getcolors())
    a = a.sum()
    print (a)
    return a
 
def get_seat_six():
    box = (836,404,836+61,404+15)
    im = ImageOps.grayscale(ImageGrab.grab(box))
    a = array(im.getcolors())
    a = a.sum()
    print (a)
    return a
 
def get_all_seats():
    get_seat_one()
    get_seat_two()
    get_seat_three()
    get_seat_four()
    get_seat_five()
    get_seat_six()

def check_bubs():

    checkFood()
    time.sleep(.05)
    checkFood2()
    time.sleep(.05)
    checkFood3()
    time.sleep(.05)
    s1 = get_seat_one()
    print (s1)
    if s1 != Blank.seat_1:
        if s1 in sushiTypes:
            print ('table 1 is occupied and needs %s' % sushiTypes[s1])
            makeFood(sushiTypes[s1])
        else:
            print ('sushi not found!\n sushiType = %i' % s1)

    else:
        print ('Table 1 unoccupied')

    clear_tables()
    mousePos(Cord.level_up)
    s = screenGrab()
    if  s.getpixel(Cord.level_up) != ((254, 242, 242)):
        print('level up')
        mousePos(Cord.level_up)
        leftClick()
        time.sleep(.05)
        mousePos(Cord.two_con)
        leftClick()
    s = screenGrab()
    time.sleep(.05)
    checkFood()
    time.sleep(.05)
    checkFood2()
    time.sleep(.05)
    checkFood3()
    time.sleep(.05)
    s2 = get_seat_two()
    if s2 != Blank.seat_2:
        if s2 in sushiTypes:
            print ('table 2 is occupied and needs %s' % sushiTypes[s2])
            makeFood(sushiTypes[s2])
        else:
            print ('sushi not found!\n sushiType = %i' % s2)

    else:
        print ('Table 2 unoccupied')

    checkFood()
    time.sleep(.05)
    checkFood2()
    time.sleep(.05)
    checkFood3()
    time.sleep(.05)
    s3 = get_seat_three()
    if s3 != Blank.seat_3:
        if s3 in sushiTypes:
            print ('table 3 is occupied and needs %s' % sushiTypes[s3])
            makeFood(sushiTypes[s3])
        else:
            print ('sushi not found!\n sushiType = %i' % s3)

    else:   
        print ('Table 3 unoccupied')
    checkFood()
    time.sleep(.05)
    checkFood2()
    time.sleep(.05)
    checkFood3()
    time.sleep(.05)
    s4 = get_seat_four()
    if s4 != Blank.seat_4:
        if s4 in sushiTypes:
            print ('table 4 is occupied and needs %s' % sushiTypes[s4])
            makeFood(sushiTypes[s4])
        else:
            print ('sushi not found!\n sushiType = %i' % s4)

    else:
        print ('Table 4 unoccupied')

    clear_tables()
    time.sleep(.05)
    checkFood()
    time.sleep(.05)
    checkFood2()
    time.sleep(.05)
    checkFood3()
    time.sleep(.05)
    s5 = get_seat_five()
    if s5 != Blank.seat_5:
        if s5 in sushiTypes:
            print ('table 5 is occupied and needs %s' % sushiTypes[s5])
            makeFood(sushiTypes[s5])
        else:
            print ('sushi not found!\n sushiType = %i' % s5)

    else:
        print ('Table 5 unoccupied')

    checkFood()
    time.sleep(.05)
    checkFood2()
    time.sleep(.05)
    checkFood3()
    time.sleep(.05)
    s6 = get_seat_six()
    if s6 != Blank.seat_6:
        if s6 in sushiTypes:
            print ('table 6 is occupied and needs %s' % sushiTypes[s6])
            makeFood(sushiTypes[s6])
        else:
            print ('sushi not found!\n sushiType = %i' % s6)

    else:
        print ('Table 6 unoccupied')

        clear_tables()
        
    


if __name__ == '__main__':
     main()
